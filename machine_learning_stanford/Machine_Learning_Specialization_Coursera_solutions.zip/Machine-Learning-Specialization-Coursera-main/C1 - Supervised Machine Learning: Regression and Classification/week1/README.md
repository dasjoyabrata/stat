### Week 1 Solutions 

<br></br>

- [Practice quiz: Regression](/C1%20-%20Supervised%20Machine%20Learning%3A%20Regression%20and%20Classification/week1/Practice%20quiz%3A%20Regression/)

- [Practice quiz: Supervised vs unsupervised learning](/C1%20-%20Supervised%20Machine%20Learning%3A%20Regression%20and%20Classification/week1/Practice%20quiz%3A%20Supervised%20vs%20unsupervised%20learning/)

- [Practice quiz: Train the model with gradient descent](/C1%20-%20Supervised%20Machine%20Learning%3A%20Regression%20and%20Classification/week1/Practice%20quiz%3A%20Train%20the%20model%20with%20gradient%20descent/)

- [Optional Labs](/C1%20-%20Supervised%20Machine%20Learning%3A%20Regression%20and%20Classification/week1/Optional%20Labs)
    - [Model Representation](/C1%20-%20Supervised%20Machine%20Learning%3A%20Regression%20and%20Classification/week1/Optional%20Labs/C1_W1_Lab03_Model_Representation_Soln.ipynb)
    - [Cost Function](/C1%20-%20Supervised%20Machine%20Learning%3A%20Regression%20and%20Classification/week1/Optional%20Labs/C1_W1_Lab04_Cost_function_Soln.ipynb)
    - [Gradient Descent](/C1%20-%20Supervised%20Machine%20Learning%3A%20Regression%20and%20Classification/week1/Optional%20Labs/C1_W1_Lab05_Gradient_Descent_Soln.ipynb)
  