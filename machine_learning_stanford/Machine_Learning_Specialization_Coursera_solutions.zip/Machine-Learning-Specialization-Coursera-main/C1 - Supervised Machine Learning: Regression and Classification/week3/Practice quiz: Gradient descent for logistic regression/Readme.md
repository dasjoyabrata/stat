![](/C1%20-%20Supervised%20Machine%20Learning:%20Regression%20and%20Classification/week3/Practice%20quiz:%20Gradient%20descent%20for%20logistic%20regression/ss1.png)
